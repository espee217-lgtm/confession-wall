const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const dotenv = require("dotenv");
const reportRoutes = require("./routes/reportRoutes");
dotenv.config();
console.log("Mongo URI:", process.env.MONGO_URI);

const app = express();

app.use(cors());
app.use(express.json());

const confessionRoutes = require("./routes/confessionRoutes");
const authRoutes = require("./routes/authRoutes");
app.use("/api/confessions", confessionRoutes);
app.use("/api/auth", authRoutes);
const { router: adminRoutes } = require("./routes/adminRoutes");
app.use("/api/admin", adminRoutes);
app.use("/api/reports", reportRoutes);

app.get("/", (req, res) => {
  res.send("Confession Wall Server is running!");
});

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✅ Connected to MongoDB");
    app.listen(5000, () => console.log("🚀 Server running on port 5000"));
  })
  .catch((err) => console.error("MongoDB connection error:", err));